export type RoomType =
  | 'office'
  | 'bedroom'
  | 'living'
  | 'closet'
  | 'kitchen'
  | 'garage'
  | 'bathroom'
  | 'pantry'
  | 'playroom';

export type OrganizationGoal =
  | 'minimalist'
  | 'family'
  | 'marie_kondo'
  | 'quick_blitz'
  | 'budget';

export interface IdentifiedIssue {
  area: string;
  problem: string;
  solution: string;
  severity: 'high' | 'medium' | 'low';
}

export interface DeclutterStep {
  id: string;
  title: string;
  category: 'keep' | 'donate_sell' | 'discard' | 'relocate' | 'organize';
  estimatedMinutes: number;
  priority: 'high' | 'medium' | 'low';
  instructions: string;
  targetArea: string;
  completed?: boolean;
}

export interface StorageRecommendation {
  name: string;
  category: string;
  reason: string;
  estimatedPriceRange: string;
  placement: string;
  inShoppingList?: boolean;
}

export interface RoomAnalysis {
  overallMessScore: number;
  clutterLevelCategory: string;
  roomSummary: string;
  identifiedIssues: IdentifiedIssue[];
  declutterSteps: DeclutterStep[];
  storageRecommendations: StorageRecommendation[];
  spatialLayoutTips: string[];
  quick15MinWin: string;
  suggestedChatPrompts: string[];
}

export interface BeforeAfterComparison {
  improvementPercentage: number;
  congratulationsHeader: string;
  detailedFeedback: string;
  keyImprovementsNoted: string[];
  proTipForMaintenance: string;
}

export interface RoomProject {
  id: string;
  name: string;
  roomType: RoomType;
  organizationGoal: OrganizationGoal;
  timeAvailable: string;
  specialNotes?: string;
  beforeImage: string;
  afterImage?: string;
  createdAt: string;
  analysis?: RoomAnalysis;
  comparison?: BeforeAfterComparison;
  completedStepIds: string[];
  notes?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  imageBase64?: string;
}

export interface SampleRoom {
  id: string;
  title: string;
  roomType: RoomType;
  goal: OrganizationGoal;
  description: string;
  imageUrl: string;
  presetAnalysis: RoomAnalysis;
}
