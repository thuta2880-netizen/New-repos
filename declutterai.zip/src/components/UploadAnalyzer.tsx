import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Sparkles, Clock, Target, Home, HelpCircle, AlertCircle, ArrowRight, Check } from 'lucide-react';
import { RoomType, OrganizationGoal, RoomAnalysis, RoomProject, SampleRoom } from '../types';
import { SAMPLE_ROOMS } from '../data/sampleRooms';

interface UploadAnalyzerProps {
  onProjectCreated: (project: RoomProject) => void;
  onSelectSample: (sample: SampleRoom) => void;
}

export const UploadAnalyzer: React.FC<UploadAnalyzerProps> = ({
  onProjectCreated,
  onSelectSample,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>('image/jpeg');
  const [projectName, setProjectName] = useState<string>('');
  const [roomType, setRoomType] = useState<RoomType>('office');
  const [organizationGoal, setOrganizationGoal] = useState<OrganizationGoal>('minimalist');
  const [timeAvailable, setTimeAvailable] = useState<string>('30 mins');
  const [specialNotes, setSpecialNotes] = useState<string>('');
  
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file (JPG, PNG, WEBP).');
        return;
      }
      setError(null);
      setImageMimeType(file.type);
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
        if (!projectName) {
          setProjectName(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setError(null);
      setImageMimeType(file.type);
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
        if (!projectName) {
          setProjectName(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleAnalyze = async () => {
    if (!selectedImage) {
      setError('Please upload a photo of your room or select a sample room.');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setLoadingStep('Uploading room photo for vision analysis...');

    try {
      const stepTimer1 = setTimeout(() => {
        setLoadingStep('Identifying cluttered surfaces, floor items, and cord tangles...');
      }, 1500);

      const stepTimer2 = setTimeout(() => {
        setLoadingStep('Generating customized step-by-step decluttering checklist & storage plan...');
      }, 3500);

      const res = await fetch('/api/analyze-room', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType: imageMimeType,
          roomType,
          organizationGoal,
          timeAvailable,
          specialNotes,
        }),
      });

      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to analyze room image.');
      }

      const analysis: RoomAnalysis = data.analysis;

      const newProject: RoomProject = {
        id: `proj_${Date.now()}`,
        name: projectName || `${roomType.toUpperCase()} Organization`,
        roomType,
        organizationGoal,
        timeAvailable,
        specialNotes,
        beforeImage: selectedImage,
        createdAt: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        }),
        analysis,
        completedStepIds: [],
      };

      onProjectCreated(newProject);
    } catch (err: any) {
      console.error('Error analyzing room:', err);
      setError(err.message || 'Error processing photo with Gemini AI. Please try again.');
    } finally {
      setIsAnalyzing(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-10" id="upload-analyzer-section">
      {/* Intro Banner */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Multimodal Vision AI Room Analysis</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Transform Clutter Into Serenity
        </h1>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          Upload a photo of any cluttered room or workspace. Our AI analyzes objects, surfaces, and space to build your step-by-step organization roadmap.
        </p>
      </div>

      {/* Main Upload Card */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Photo Upload Zone */}
          <div className="lg:col-span-6 space-y-4">
            <label className="block text-sm font-semibold text-slate-200">
              1. Room Photo
            </label>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
              id="room-file-input"
            />

            <div
              onClick={() => fileInputRef.current?.click()}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              className={`relative border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[280px] ${
                selectedImage
                  ? 'border-emerald-500/50 bg-slate-950/80 hover:border-emerald-400'
                  : 'border-slate-700 bg-slate-950/40 hover:border-slate-500 hover:bg-slate-950/60'
              }`}
              id="photo-dropzone"
            >
              {selectedImage ? (
                <div className="relative w-full h-full flex flex-col items-center">
                  <img
                    src={selectedImage}
                    alt="Uploaded Room"
                    className="max-h-[240px] rounded-lg object-contain border border-slate-800 shadow-md"
                  />
                  <div className="mt-3 flex items-center gap-2 text-xs font-medium text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-500/30">
                    <Check className="w-3.5 h-3.5" />
                    <span>Photo Ready for Analysis</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1">Click or drag to replace image</span>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-emerald-400 border border-slate-700 shadow-inner">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">
                      Click to upload room photo
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Drag and drop JPG, PNG, or WEBP photo
                    </p>
                  </div>
                  <span className="inline-block px-3 py-1 text-xs rounded-md bg-slate-800 text-slate-300 font-mono">
                    Desk • Closet • Kitchen • Bedroom • Garage
                  </span>
                </div>
              )}
            </div>

            {/* Quick Sample Selector */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                Or try a instant sample room:
              </span>
              <div className="grid grid-cols-3 gap-2">
                {SAMPLE_ROOMS.map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => onSelectSample(sample)}
                    className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-lg text-left text-xs transition-all space-y-1 group"
                    id={`sample-button-${sample.id}`}
                  >
                    <p className="font-semibold text-slate-200 group-hover:text-emerald-400 truncate">
                      {sample.title}
                    </p>
                    <p className="text-[10px] text-slate-400 line-clamp-1">{sample.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Configuration Form */}
          <div className="lg:col-span-6 space-y-5">
            <label className="block text-sm font-semibold text-slate-200">
              2. Room Preferences & Goals
            </label>

            {/* Room Name */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                Project / Room Name
              </label>
              <input
                type="text"
                placeholder="e.g. Living Room Desk, Pantry Shelves"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none transition-colors"
                id="input-project-name"
              />
            </div>

            {/* Room Type Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5 flex items-center gap-1">
                <Home className="w-3.5 h-3.5 text-emerald-400" />
                Room Type
              </label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value as RoomType)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none transition-colors"
                id="select-room-type"
              >
                <option value="office">Home Office / Desk</option>
                <option value="bedroom">Bedroom</option>
                <option value="closet">Closet / Wardrobe</option>
                <option value="kitchen">Kitchen Counter</option>
                <option value="pantry">Kitchen Pantry</option>
                <option value="living">Living Room</option>
                <option value="garage">Garage / Workshop</option>
                <option value="bathroom">Bathroom Vanity</option>
                <option value="playroom">Kids Playroom</option>
              </select>
            </div>

            {/* Organization Goal */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5 flex items-center gap-1">
                <Target className="w-3.5 h-3.5 text-blue-400" />
                Decluttering Goal
              </label>
              <select
                value={organizationGoal}
                onChange={(e) => setOrganizationGoal(e.target.value as OrganizationGoal)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none transition-colors"
                id="select-organization-goal"
              >
                <option value="minimalist">Minimalist Zen (Clean surfaces, minimal items)</option>
                <option value="family">Family Functional (Easy access, durable grouping)</option>
                <option value="marie_kondo">Marie Kondo Spark Joy (Category sorting)</option>
                <option value="quick_blitz">15-Min Rapid Blitz (High priority fixes first)</option>
                <option value="budget">Budget-Friendly Storage (Repurpose existing bins)</option>
              </select>
            </div>

            {/* Time Available */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                Available Time
              </label>
              <select
                value={timeAvailable}
                onChange={(e) => setTimeAvailable(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none transition-colors"
                id="select-time-available"
              >
                <option value="15 mins">15 Minutes (Quick Win)</option>
                <option value="30 mins">30 Minutes (Targeted Blitz)</option>
                <option value="1 hour">1 Hour (Deep Declutter)</option>
                <option value="Weekend project">Weekend Transformation</option>
              </select>
            </div>

            {/* Special Instructions */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                Special Focus / Questions (Optional)
              </label>
              <textarea
                placeholder="e.g., 'Need space for my laptop dock', 'Where do I hide these power cords?'"
                value={specialNotes}
                onChange={(e) => setSpecialNotes(e.target.value)}
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none transition-colors resize-none"
                id="textarea-special-notes"
              />
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs sm:text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Submit Action Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleAnalyze}
            disabled={isAnalyzing || !selectedImage}
            className={`w-full py-4 px-6 rounded-xl font-bold text-sm sm:text-base transition-all flex items-center justify-center gap-3 shadow-lg ${
              isAnalyzing || !selectedImage
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/20 active:scale-[0.99]'
            }`}
            id="analyze-room-button"
          >
            {isAnalyzing ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{loadingStep || 'Analyzing Room Photo with AI...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 fill-slate-950" />
                <span>Generate AI Organization Plan</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
