import React from 'react';
import { ShoppingBag, Trash2, CheckCircle2, Printer, ExternalLink, Package } from 'lucide-react';
import { StorageRecommendation } from '../types';

interface ShoppingListProps {
  items: StorageRecommendation[];
  onRemoveItem: (itemName: string) => void;
  onClearList: () => void;
}

export const ShoppingList: React.FC<ShoppingListProps> = ({
  items,
  onRemoveItem,
  onClearList,
}) => {
  const handlePrint = () => {
    window.print();
  };

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-blue-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white">Your Storage List is Empty</h2>
          <p className="text-slate-400 text-sm max-w-md mx-auto">
            When analyzing room photos, click "Save to Storage List" on any recommended bins, racks, or cable sleeves to collect them here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8" id="shopping-list-section">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
            <ShoppingBag className="w-7 h-7 text-blue-400" />
            <span>Storage & Organizer Shopping List</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Saved organizers recommended across your room projects. ({items.length} items saved)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print List</span>
          </button>

          <button
            type="button"
            onClick={onClearList}
            className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All</span>
          </button>
        </div>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-500/20">
                    {item.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-400">{item.estimatedPriceRange}</span>
                </div>

                <h3 className="font-bold text-base text-white">{item.name}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{item.reason}</p>
                <p className="text-[11px] text-slate-500 italic">Target Placement: {item.placement}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-900">
                <a
                  href={`https://www.google.com/search?q=${encodeURIComponent(item.name + ' storage organizer')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
                >
                  <span>Search Online Deals</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <button
                  type="button"
                  onClick={() => onRemoveItem(item.name)}
                  className="text-xs text-slate-500 hover:text-rose-400 p-1 transition-colors"
                  title="Remove item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
