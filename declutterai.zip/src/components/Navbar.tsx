import React from 'react';
import { Sparkles, Camera, FolderCheck, Bot, ShoppingBag, CheckCircle2 } from 'lucide-react';

interface NavbarProps {
  activeTab: 'upload' | 'projects' | 'chat' | 'shopping';
  setActiveTab: (tab: 'upload' | 'projects' | 'chat' | 'shopping') => void;
  projectsCount: number;
  shoppingItemsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  projectsCount,
  shoppingItemsCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div 
          onClick={() => setActiveTab('upload')}
          className="flex items-center gap-3 cursor-pointer group"
          id="brand-logo"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-500 to-emerald-400 p-0.5 shadow-lg group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-emerald-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white">Declutter<span className="text-emerald-400">AI</span></span>
              <span className="text-[10px] uppercase tracking-widest font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Pro</span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">AI Room Organizer & Decluttering Coach</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            id="nav-tab-upload"
            onClick={() => setActiveTab('upload')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'upload'
                ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span className="hidden md:inline">Analyze Room</span>
          </button>

          <button
            id="nav-tab-projects"
            onClick={() => setActiveTab('projects')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all relative ${
              activeTab === 'projects'
                ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FolderCheck className="w-4 h-4" />
            <span className="hidden md:inline">My Projects</span>
            {projectsCount > 0 && (
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'projects' ? 'bg-slate-950 text-emerald-400' : 'bg-slate-800 text-emerald-400 border border-slate-700'
              }`}>
                {projectsCount}
              </span>
            )}
          </button>

          <button
            id="nav-tab-chat"
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'chat'
                ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span className="hidden md:inline">AI Coach</span>
          </button>

          <button
            id="nav-tab-shopping"
            onClick={() => setActiveTab('shopping')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all relative ${
              activeTab === 'shopping'
                ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden md:inline">Storage List</span>
            {shoppingItemsCount > 0 && (
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'shopping' ? 'bg-slate-950 text-emerald-400' : 'bg-slate-800 text-emerald-400 border border-slate-700'
              }`}>
                {shoppingItemsCount}
              </span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};
