import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, User, RefreshCw, Paperclip, CheckCircle, Home, Image as ImageIcon } from 'lucide-react';
import { ChatMessage, RoomProject } from '../types';

interface AICoachChatProps {
  initialPrompt?: string | null;
  activeProject?: RoomProject | null;
  onClearInitialPrompt?: () => void;
}

export const AICoachChat: React.FC<AICoachChatProps> = ({
  initialPrompt,
  activeProject,
  onClearInitialPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome_1',
      role: 'model',
      content: "Hello! I'm DeclutterAI, your personal organization coach. I can help you sort paper clutter, organize cables, choose storage bins, build daily tidy routines, or stay motivated. What space are we working on today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle incoming initial prompt if redirected from room analysis page
  useEffect(() => {
    if (initialPrompt) {
      handleSendMessage(initialPrompt);
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() && !attachedImage) return;

    const userMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      imageBase64: attachedImage || undefined,
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInput('');
    const currentAttachedImage = attachedImage;
    setAttachedImage(null);
    setIsSending(true);

    try {
      // Build conversation payload for Gemini server endpoint
      const payloadMessages = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const roomContext = activeProject?.analysis ? {
        roomType: activeProject.roomType,
        organizationGoal: activeProject.organizationGoal,
        clutterLevelCategory: activeProject.analysis.clutterLevelCategory,
        overallMessScore: activeProject.analysis.overallMessScore,
        roomSummary: activeProject.analysis.roomSummary,
      } : undefined;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          imageBase64: currentAttachedImage || activeProject?.beforeImage || undefined,
          roomContext,
        }),
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to send message.');

      const modelReply: ChatMessage = {
        id: `reply_${Date.now()}`,
        role: 'model',
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, modelReply]);
    } catch (err: any) {
      console.error('Error in AI Coach Chat:', err);
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'model',
        content: `Sorry, I encountered an error: ${err.message || 'Unable to connect to Gemini AI server.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setAttachedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const presetPrompts = [
    'How do I stay motivated when feeling overwhelmed by clutter?',
    'What is the 5-minute end-of-day room reset habit?',
    'How should I organize loose charger cables and cords?',
    'What are the best rules for sorting paper and mail clutter?',
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6" id="ai-coach-chat-section">
      {/* Header Banner */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-md flex-shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Bot className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white">DeclutterAI Coach</h1>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>
            </div>
            <p className="text-xs text-slate-400">Interactive multi-turn organization & decluttering advice</p>
          </div>
        </div>

        {activeProject && (
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <Home className="w-3.5 h-3.5 text-emerald-400" />
            <span>Active Room: <strong className="text-white">{activeProject.name}</strong></span>
          </div>
        )}
      </div>

      {/* Main Chat Thread Container */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col h-[520px]">
        
        {/* Messages Thread */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4" id="chat-messages-container">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'model' && (
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 mt-1">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed space-y-2 shadow-sm ${
                  msg.role === 'user'
                    ? 'bg-emerald-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-tl-none'
                }`}
              >
                {msg.imageBase64 && (
                  <div className="rounded-lg overflow-hidden border border-slate-800 max-h-40 mb-2">
                    <img src={msg.imageBase64} alt="Attached" className="w-full h-full object-cover" />
                  </div>
                )}

                <div className="whitespace-pre-wrap">{msg.content}</div>

                <div className={`text-[10px] text-right ${msg.role === 'user' ? 'text-slate-900/70 font-mono' : 'text-slate-500 font-mono'}`}>
                  {msg.timestamp}
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 flex-shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isSending && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-950 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-xs text-slate-400 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce" />
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.4s]" />
                <span>Coach is writing recommendations...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Preset Prompt Chips */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 overflow-x-auto flex items-center gap-2">
          <span className="text-[11px] font-medium text-slate-400 flex-shrink-0">Quick Questions:</span>
          {presetPrompts.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(p)}
              className="text-[11px] px-3 py-1 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 whitespace-nowrap transition-colors flex-shrink-0"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 space-y-2">
          {attachedImage && (
            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs text-emerald-400">
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Image Attached</span>
              <button
                type="button"
                onClick={() => setAttachedImage(null)}
                className="ml-auto text-slate-500 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 text-slate-400 hover:text-emerald-400 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors"
              title="Attach photo"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <input
              type="text"
              placeholder="Ask coach anything about organizing your space..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isSending}
              className="flex-1 bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none transition-colors"
              id="input-chat-message"
            />

            <button
              type="submit"
              disabled={isSending || (!input.trim() && !attachedImage)}
              className="p-2.5 sm:px-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 rounded-xl font-bold transition-all flex items-center justify-center gap-1.5"
              id="button-send-chat"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline text-xs">Send</span>
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
