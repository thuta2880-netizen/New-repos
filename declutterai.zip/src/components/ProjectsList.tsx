import React from 'react';
import { RoomProject } from '../types';
import { FolderCheck, Trash2, ArrowRight, CheckCircle2, Clock, Sparkles, Plus } from 'lucide-react';

interface ProjectsListProps {
  projects: RoomProject[];
  onSelectProject: (project: RoomProject) => void;
  onDeleteProject: (projectId: string) => void;
  onNewProject: () => void;
}

export const ProjectsList: React.FC<ProjectsListProps> = ({
  projects,
  onSelectProject,
  onDeleteProject,
  onNewProject,
}) => {
  if (projects.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-emerald-400">
          <FolderCheck className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white">No Room Projects Yet</h2>
          <p className="text-slate-400 text-sm max-w-md mx-auto">
            Upload a room photo to start your first AI organization plan and decluttering checklist.
          </p>
        </div>
        <button
          type="button"
          onClick={onNewProject}
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm inline-flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Analyze New Room Photo</span>
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8" id="projects-list-section">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
            <FolderCheck className="w-7 h-7 text-emerald-400" />
            <span>My Room Projects</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">Track and manage your room decluttering transformations.</p>
        </div>

        <button
          type="button"
          onClick={onNewProject}
          className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs sm:text-sm font-bold inline-flex items-center gap-2 shadow-md transition-all self-start"
        >
          <Plus className="w-4 h-4" />
          <span>New Room Photo</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => {
          const totalSteps = project.analysis?.declutterSteps?.length || 0;
          const completedSteps = (project.completedStepIds || []).length;
          const percent = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

          return (
            <div
              key={project.id}
              className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl hover:border-slate-700 transition-all flex flex-col justify-between group"
              id={`project-card-${project.id}`}
            >
              {/* Image Preview */}
              <div className="relative h-44 bg-slate-950 overflow-hidden cursor-pointer" onClick={() => onSelectProject(project)}>
                <img
                  src={project.beforeImage}
                  alt={project.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider text-emerald-400 border border-slate-700">
                  {project.roomType}
                </div>

                {project.afterImage && (
                  <div className="absolute top-3 right-3 bg-emerald-950/90 backdrop-blur px-2.5 py-1 rounded-md text-[10px] font-bold text-emerald-300 border border-emerald-500/40">
                    ✨ After Photo Added
                  </div>
                )}
              </div>

              {/* Card Details */}
              <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{project.createdAt}</span>
                    <span className="capitalize text-slate-300">{project.timeAvailable}</span>
                  </div>
                  <h3 
                    onClick={() => onSelectProject(project)}
                    className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors cursor-pointer line-clamp-1"
                  >
                    {project.name}
                  </h3>
                  
                  {project.analysis && (
                    <p className="text-xs text-slate-400 line-clamp-2">
                      {project.analysis.roomSummary}
                    </p>
                  )}
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
                    <span>Checklist Progress</span>
                    <span className="text-emerald-400">{completedSteps}/{totalSteps} Tasks ({percent}%)</span>
                  </div>
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full bg-emerald-500 transition-all duration-300"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                {/* Actions Footer */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => onDeleteProject(project.id)}
                    className="p-2 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                    title="Delete project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectProject(project)}
                    className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-emerald-400 flex items-center gap-1.5 transition-colors"
                  >
                    <span>View Plan</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
