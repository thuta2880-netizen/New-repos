import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  Package,
  Sparkles,
  Zap,
  ArrowRight,
  MessageSquare,
  Clock,
  Tag,
  Filter,
  Check,
  Plus,
  Compass,
  Trophy,
  Upload,
  RotateCcw,
  ShoppingBag
} from 'lucide-react';
import { RoomProject, DeclutterStep, StorageRecommendation } from '../types';

interface AnalysisResultsProps {
  project: RoomProject;
  onUpdateProject: (updated: RoomProject) => void;
  onOpenChatWithPrompt: (prompt: string, projectContext?: RoomProject) => void;
  onToggleShoppingItem: (item: StorageRecommendation) => void;
  shoppingListNames: string[];
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({
  project,
  onUpdateProject,
  onOpenChatWithPrompt,
  onToggleShoppingItem,
  shoppingListNames,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  
  // Before & After Upload Modal State
  const [showAfterModal, setShowAfterModal] = useState<boolean>(false);
  const [afterImageBase64, setAfterImageBase64] = useState<string | null>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);
  const [compareError, setCompareError] = useState<string | null>(null);

  if (!project.analysis) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center text-slate-400 space-y-4">
        <p>No analysis data found for this project.</p>
      </div>
    );
  }

  const { analysis } = project;

  // Toggle checklist step completed state
  const handleToggleStep = (stepId: string) => {
    const currentCompleted = project.completedStepIds || [];
    const isAlreadyCompleted = currentCompleted.includes(stepId);

    const updatedCompleted = isAlreadyCompleted
      ? currentCompleted.filter((id) => id !== stepId)
      : [...currentCompleted, stepId];

    const updatedProject: RoomProject = {
      ...project,
      completedStepIds: updatedCompleted,
    };

    onUpdateProject(updatedProject);
  };

  // Filtered steps logic
  const steps = analysis.declutterSteps || [];
  const filteredSteps = steps.filter((step) => {
    if (filterCategory !== 'all' && step.category !== filterCategory) return false;
    if (filterPriority !== 'all' && step.priority !== filterPriority) return false;
    return true;
  });

  const totalStepsCount = steps.length;
  const completedCount = (project.completedStepIds || []).length;
  const progressPercent = totalStepsCount > 0 ? Math.round((completedCount / totalStepsCount) * 100) : 0;

  // Clutter Score Color logic
  const getScoreColor = (score: number) => {
    if (score <= 3) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (score <= 6) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    if (score <= 8) return 'text-orange-400 bg-orange-500/10 border-orange-500/30';
    return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
  };

  // Category Badge label & color
  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'keep':
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">Keep & Store</span>;
      case 'donate_sell':
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Donate / Sell</span>;
      case 'discard':
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">Discard / Recycle</span>;
      case 'relocate':
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">Relocate</span>;
      case 'organize':
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">Group & Organize</span>;
      default:
        return <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">{cat}</span>;
    }
  };

  // Compare After Photo Handler
  const handleCompareAfter = async () => {
    if (!afterImageBase64) {
      setCompareError('Please upload an After photo first.');
      return;
    }

    setIsComparing(true);
    setCompareError(null);

    try {
      const res = await fetch('/api/compare-after', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beforeImageBase64: project.beforeImage,
          afterImageBase64: afterImageBase64,
          roomType: project.roomType,
        }),
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to evaluate photos.');

      const updatedProject: RoomProject = {
        ...project,
        afterImage: afterImageBase64,
        comparison: data.comparison,
      };

      onUpdateProject(updatedProject);
      setShowAfterModal(false);
    } catch (err: any) {
      console.error('Error comparing photos:', err);
      setCompareError(err.message || 'Error processing comparison.');
    } finally {
      setIsComparing(false);
    }
  };

  const handleAfterFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setAfterImageBase64(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8" id="analysis-results-section">
      
      {/* Top Header Card */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-emerald-400">
                {project.roomType.toUpperCase()}
              </span>
              <span className="text-xs text-slate-400">• Created {project.createdAt}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              {project.name}
            </h1>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowAfterModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs sm:text-sm font-semibold transition-colors"
              id="upload-after-photo-button"
            >
              <Upload className="w-4 h-4" />
              <span>{project.afterImage ? 'Update After Photo' : 'Upload "After" Photo'}</span>
            </button>
          </div>
        </div>

        {/* Room Photo & Clutter Score Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          
          {/* Photo Preview Column */}
          <div className="md:col-span-5 space-y-3">
            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-md">
              <img
                src={project.beforeImage}
                alt="Room Before"
                className="w-full h-56 sm:h-64 object-cover"
              />
              <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded-md text-[11px] font-bold text-white border border-slate-700">
                BEFORE Photo
              </div>
            </div>

            {/* If After Photo Exists */}
            {project.afterImage && (
              <div className="relative rounded-xl overflow-hidden border border-emerald-500/30 bg-slate-950 shadow-md">
                <img
                  src={project.afterImage}
                  alt="Room After"
                  className="w-full h-56 sm:h-64 object-cover"
                />
                <div className="absolute top-3 left-3 bg-emerald-950/90 backdrop-blur px-2.5 py-1 rounded-md text-[11px] font-bold text-emerald-400 border border-emerald-500/40">
                  AFTER Photo
                </div>
              </div>
            )}
          </div>

          {/* Summary & Score Column */}
          <div className="md:col-span-7 space-y-5">
            {/* Clutter Score Gauge */}
            <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className={`w-16 h-16 rounded-xl flex flex-col items-center justify-center border font-mono font-extrabold text-2xl shadow-inner ${getScoreColor(analysis.overallMessScore)}`}>
                <span>{analysis.overallMessScore}</span>
                <span className="text-[10px] opacity-75 font-sans font-normal">/10</span>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Clutter Assessment Index</p>
                <p className="text-lg font-bold text-white">{analysis.clutterLevelCategory}</p>
                <p className="text-xs text-slate-400 mt-0.5">Goal: <span className="text-slate-200 capitalize">{project.organizationGoal.replace('_', ' ')}</span> ({project.timeAvailable})</p>
              </div>
            </div>

            {/* Room Summary text */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                <Sparkles className="w-4 h-4" />
                <span>AI Organizer Analysis Summary</span>
              </div>
              <p className="text-slate-300 text-sm leading-relaxed">
                {analysis.roomSummary}
              </p>
            </div>

            {/* Quick 15-Min Win Highlight */}
            {analysis.quick15MinWin && (
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/20 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                  <Zap className="w-4 h-4 fill-amber-400" />
                  <span>Instant 15-Minute Win</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-200 font-medium">
                  "{analysis.quick15MinWin}"
                </p>
              </div>
            )}

            {/* Comparison Feedback if available */}
            {project.comparison && (
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                    <Trophy className="w-4 h-4" />
                    {project.comparison.congratulationsHeader}
                  </span>
                  <span className="text-xs font-extrabold px-2 py-0.5 rounded bg-emerald-400 text-slate-950">
                    +{project.comparison.improvementPercentage}% Transformation
                  </span>
                </div>
                <p className="text-xs text-slate-200">{project.comparison.detailedFeedback}</p>
                <p className="text-[11px] text-emerald-300 font-medium">💡 Maintenance Tip: {project.comparison.proTipForMaintenance}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Checklist & Action Steps Section */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        
        {/* Section Title & Progress Bar */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Step-by-Step Decluttering Checklist</span>
              </h2>
              <p className="text-xs text-slate-400">Complete tasks at your own pace. Progress saves automatically.</p>
            </div>
            
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
              <span>{completedCount} of {totalStepsCount} Tasks Done</span>
              <span className="text-slate-500">({progressPercent}%)</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-3 pt-2 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mr-2">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter:</span>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'all', label: 'All Categories' },
              { id: 'keep', label: 'Keep' },
              { id: 'donate_sell', label: 'Donate/Sell' },
              { id: 'discard', label: 'Discard' },
              { id: 'relocate', label: 'Relocate' },
              { id: 'organize', label: 'Organize' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setFilterCategory(cat.id)}
                className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
                  filterCategory === cat.id
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Steps List */}
        <div className="space-y-3">
          {filteredSteps.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">No steps match the selected filter.</p>
          ) : (
            filteredSteps.map((step) => {
              const isDone = (project.completedStepIds || []).includes(step.id);
              return (
                <div
                  key={step.id}
                  onClick={() => handleToggleStep(step.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-4 ${
                    isDone
                      ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 shadow-sm'
                  }`}
                  id={`step-card-${step.id}`}
                >
                  {/* Custom Checkbox */}
                  <div className={`mt-0.5 w-6 h-6 rounded-lg flex items-center justify-center border transition-all flex-shrink-0 ${
                    isDone
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                      : 'border-slate-700 bg-slate-900 hover:border-emerald-500'
                  }`}>
                    {isDone && <Check className="w-4 h-4 stroke-[3]" />}
                  </div>

                  {/* Step Content */}
                  <div className="flex-1 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold text-sm ${isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                          {step.title}
                        </span>
                        {getCategoryBadge(step.category)}
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3 text-amber-400" />
                          {step.estimatedMinutes}m
                        </span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${
                          step.priority === 'high' ? 'bg-rose-500/20 text-rose-300' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {step.priority}
                        </span>
                      </div>
                    </div>

                    <p className={`text-xs sm:text-sm leading-relaxed ${isDone ? 'text-slate-500' : 'text-slate-300'}`}>
                      {step.instructions}
                    </p>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-slate-500">Target Area: <strong className="text-slate-400">{step.targetArea}</strong></span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenChatWithPrompt(`How specifically should I complete this step: "${step.title}" in my room?`, project);
                        }}
                        className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 hover:underline"
                      >
                        <MessageSquare className="w-3 h-3" />
                        Ask Coach about this
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Identified Issues & Clutter Zones Grid */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <span>Identified Clutter Zones & AI Solutions</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Specific areas flagged in your room photo that require targeted organization.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(analysis.identifiedIssues || []).map((issue, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white bg-slate-800 px-2.5 py-0.5 rounded">
                  📍 {issue.area}
                </span>
                <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                  issue.severity === 'high' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-amber-500/10 text-amber-400'
                }`}>
                  {issue.severity} priority
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium"><strong className="text-rose-400">Problem:</strong> {issue.problem}</p>
              <p className="text-xs text-emerald-300 leading-relaxed"><strong className="text-emerald-400">Solution:</strong> {issue.solution}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Storage & Container Recommendations Grid */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-400" />
              <span>Recommended Storage & Organizers</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">Tailored organizers to maintain this room's structure long-term.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(analysis.storageRecommendations || []).map((item, idx) => {
            const inList = shoppingListNames.includes(item.name);
            return (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-3">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-500/20">
                      {item.category}
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-300">{item.estimatedPriceRange}</span>
                  </div>
                  <h3 className="font-bold text-sm text-white">{item.name}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{item.reason}</p>
                  <p className="text-[11px] text-slate-500 italic">Location: {item.placement}</p>
                </div>

                <button
                  type="button"
                  onClick={() => onToggleShoppingItem(item)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                    inList
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {inList ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Added to Storage List</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save to Storage List</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Spatial & Layout Advice */}
      {analysis.spatialLayoutTips && analysis.spatialLayoutTips.length > 0 && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-4">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-purple-400" />
            <span>Spatial & Furniture Layout Tips</span>
          </h2>
          <ul className="space-y-2">
            {analysis.spatialLayoutTips.map((tip, idx) => (
              <li key={idx} className="text-xs sm:text-sm text-slate-300 flex items-start gap-2.5">
                <span className="text-purple-400 font-bold">•</span>
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Ask Coach Quick Prompts */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-base">Have Questions About This Room?</h3>
            <p className="text-xs text-slate-400">Click any prompt below to chat directly with your AI Organizer Coach.</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {(analysis.suggestedChatPrompts || [
            'How can I keep this room organized every week?',
            'Where should I store extra cables in this space?',
            'Give me a 5-minute daily reset routine for this room.'
          ]).map((promptText, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onOpenChatWithPrompt(promptText, project)}
              className="px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs text-slate-200 font-medium transition-all text-left flex items-center gap-2 group"
            >
              <span>"{promptText}"</span>
              <ArrowRight className="w-3.5 h-3.5 text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
            </button>
          ))}
        </div>
      </div>

      {/* Before & After Upload Modal */}
      {showAfterModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-emerald-400" />
                <span>Upload "AFTER" Photo</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAfterModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Finished decluttering? Snap a photo of your clean space to get an AI improvement score and congratulations!
            </p>

            <div className="space-y-4">
              <input
                type="file"
                onChange={handleAfterFileChange}
                accept="image/*"
                className="block w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-500 file:text-slate-950 hover:file:bg-emerald-400 cursor-pointer"
              />

              {afterImageBase64 && (
                <div className="rounded-xl overflow-hidden border border-slate-800 max-h-48">
                  <img src={afterImageBase64} alt="After Preview" className="w-full h-full object-cover" />
                </div>
              )}

              {compareError && (
                <p className="text-xs text-rose-400">{compareError}</p>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAfterModal(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCompareAfter}
                disabled={isComparing || !afterImageBase64}
                className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isComparing ? 'AI Evaluating...' : 'Evaluate Transformation'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
