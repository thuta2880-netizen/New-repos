import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { UploadAnalyzer } from './components/UploadAnalyzer';
import { AnalysisResults } from './components/AnalysisResults';
import { ProjectsList } from './components/ProjectsList';
import { AICoachChat } from './components/AICoachChat';
import { ShoppingList } from './components/ShoppingList';
import { RoomProject, StorageRecommendation, SampleRoom } from './types';
import { SAMPLE_ROOMS } from './data/sampleRooms';

export default function App() {
  const [activeTab, setActiveTab] = useState<'upload' | 'projects' | 'chat' | 'shopping'>('upload');
  
  // Projects persistence in localStorage
  const [projects, setProjects] = useState<RoomProject[]>(() => {
    try {
      const saved = localStorage.getItem('declutter_ai_projects');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading projects from localStorage:', e);
    }
    // Load sample project by default if empty
    const defaultSample = SAMPLE_ROOMS[0];
    return [
      {
        id: 'sample_desk_project',
        name: defaultSample.title,
        roomType: defaultSample.roomType,
        organizationGoal: defaultSample.goal,
        timeAvailable: '30 mins',
        beforeImage: defaultSample.imageUrl,
        createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        analysis: defaultSample.presetAnalysis,
        completedStepIds: ['s1'],
      },
    ];
  });

  const [selectedProject, setSelectedProject] = useState<RoomProject | null>(projects[0] || null);

  // Storage Shopping list persistence
  const [shoppingList, setShoppingList] = useState<StorageRecommendation[]>(() => {
    try {
      const saved = localStorage.getItem('declutter_ai_shopping_list');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading shopping list:', e);
    }
    // Default pre-populated item from sample project
    return [
      {
        name: 'Under-Desk Wire Mesh Cable Tray',
        category: 'Cable Mgmt',
        reason: 'Hides power strip and keeps cords suspended cleanly off the floor.',
        estimatedPriceRange: '$12 - $18',
        placement: 'Underneath back edge of desk',
      },
    ];
  });

  const [initialCoachPrompt, setInitialCoachPrompt] = useState<string | null>(null);

  // Save projects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('declutter_ai_projects', JSON.stringify(projects));
    } catch (e) {
      console.error('Failed to save projects:', e);
    }
  }, [projects]);

  // Save shopping list to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('declutter_ai_shopping_list', JSON.stringify(shoppingList));
    } catch (e) {
      console.error('Failed to save shopping list:', e);
    }
  }, [shoppingList]);

  // Handle new project created via UploadAnalyzer
  const handleProjectCreated = (newProject: RoomProject) => {
    setProjects((prev) => [newProject, ...prev]);
    setSelectedProject(newProject);
    setActiveTab('projects');
  };

  // Handle instant sample room selection
  const handleSelectSample = (sample: SampleRoom) => {
    const newProject: RoomProject = {
      id: `sample_${sample.id}_${Date.now()}`,
      name: sample.title,
      roomType: sample.roomType,
      organizationGoal: sample.goal,
      timeAvailable: '30 mins',
      beforeImage: sample.imageUrl,
      createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      analysis: sample.presetAnalysis,
      completedStepIds: [],
    };

    setProjects((prev) => [newProject, ...prev]);
    setSelectedProject(newProject);
    setActiveTab('projects');
  };

  // Update existing project (e.g. completed steps or after photo comparison)
  const handleUpdateProject = (updated: RoomProject) => {
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProject?.id === updated.id) {
      setSelectedProject(updated);
    }
  };

  // Delete project
  const handleDeleteProject = (projectId: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    if (selectedProject?.id === projectId) {
      const remaining = projects.filter((p) => p.id !== projectId);
      setSelectedProject(remaining[0] || null);
    }
  };

  // Open Chatbot with preloaded question prompt
  const handleOpenChatWithPrompt = (prompt: string, projectContext?: RoomProject) => {
    if (projectContext) {
      setSelectedProject(projectContext);
    }
    setInitialCoachPrompt(prompt);
    setActiveTab('chat');
  };

  // Toggle Shopping list items
  const handleToggleShoppingItem = (item: StorageRecommendation) => {
    const exists = shoppingList.some((i) => i.name === item.name);
    if (exists) {
      setShoppingList((prev) => prev.filter((i) => i.name !== item.name));
    } else {
      setShoppingList((prev) => [...prev, item]);
    }
  };

  const shoppingItemNames = shoppingList.map((i) => i.name);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
        }}
        projectsCount={projects.length}
        shoppingItemsCount={shoppingList.length}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'upload' && (
          <UploadAnalyzer
            onProjectCreated={handleProjectCreated}
            onSelectSample={handleSelectSample}
          />
        )}

        {activeTab === 'projects' && (
          <div>
            {selectedProject ? (
              <div className="space-y-4">
                {/* Back button bar */}
                <div className="max-w-6xl mx-auto px-4 pt-6 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setSelectedProject(null)}
                    className="text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-800 transition-colors"
                  >
                    ← Back to All Projects ({projects.length})
                  </button>
                </div>

                <AnalysisResults
                  project={selectedProject}
                  onUpdateProject={handleUpdateProject}
                  onOpenChatWithPrompt={handleOpenChatWithPrompt}
                  onToggleShoppingItem={handleToggleShoppingItem}
                  shoppingListNames={shoppingItemNames}
                />
              </div>
            ) : (
              <ProjectsList
                projects={projects}
                onSelectProject={(proj) => setSelectedProject(proj)}
                onDeleteProject={handleDeleteProject}
                onNewProject={() => setActiveTab('upload')}
              />
            )}
          </div>
        )}

        {activeTab === 'chat' && (
          <AICoachChat
            initialPrompt={initialCoachPrompt}
            activeProject={selectedProject}
            onClearInitialPrompt={() => setInitialCoachPrompt(null)}
          />
        )}

        {activeTab === 'shopping' && (
          <ShoppingList
            items={shoppingList}
            onRemoveItem={(name) => setShoppingList((prev) => prev.filter((i) => i.name !== name))}
            onClearList={() => setShoppingList([])}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-6 text-center text-xs text-slate-500 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>DeclutterAI • AI-Powered Room Organization & Decluttering Coach</span>
          <span>Powered by Gemini 3.6 Multimodal AI</span>
        </div>
      </footer>
    </div>
  );
}
