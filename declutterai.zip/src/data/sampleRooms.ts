import { SampleRoom } from '../types';

// Clean SVG room illustrations encoded as SVG Data URLs for reliable local rendering
const createRoomSvg = (bgColor: string, title: string, items: string[]) => {
  const itemsText = items.map((it, idx) => `<text x="50" y="${140 + idx * 28}" font-family="sans-serif" font-size="14" fill="#334155">• ${it}</text>`).join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
    <rect width="600" height="400" fill="${bgColor}" rx="16"/>
    <rect x="20" y="20" width="560" height="360" fill="#ffffff" fill-opacity="0.8" rx="12" stroke="#cbd5e1" stroke-width="2"/>
    <path d="M 40 320 L 560 320" stroke="#94a3b8" stroke-width="3" stroke-dasharray="6,6"/>
    <rect x="50" y="50" width="500" height="50" fill="#3b82f6" fill-opacity="0.1" rx="8"/>
    <text x="70" y="82" font-family="sans-serif" font-size="20" font-weight="bold" fill="#1e293b">📷 Sample Room: ${title}</text>
    ${itemsText}
    <rect x="380" y="120" width="170" height="180" fill="#f1f5f9" stroke="#94a3b8" rx="8" stroke-dasharray="4,4"/>
    <text x="400" y="210" font-family="sans-serif" font-size="13" fill="#64748b" text-anchor="middle" x-align="center">Clutter Zone Identified</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export const SAMPLE_ROOMS: SampleRoom[] = [
  {
    id: 'sample_desk',
    title: 'Cluttered Home Office Desk',
    roomType: 'office',
    goal: 'minimalist',
    description: 'Tangled charging cables, loose receipts, stacked paper, and coffee cups crowding the monitor.',
    imageUrl: createRoomSvg('#eff6ff', 'Home Office Desk', [
      'Entangled monitor & phone charging cables',
      'Unsorted receipt & document paper stack',
      '3 unused coffee mugs & water bottles',
      'Scattered pens, sticky notes, & gadgets'
    ]),
    presetAnalysis: {
      overallMessScore: 7.4,
      clutterLevelCategory: 'Heavy Surface & Cable Clutter',
      roomSummary: 'Your desk has high productivity potential! The main friction stems from tangled power cables across your workspace and loose papers competing with monitor area.',
      identifiedIssues: [
        {
          area: 'Desk Surface Center',
          problem: 'Piles of loose papers and receipts blocking keyboard motion.',
          solution: 'Establish a single tiered inbox tray to sort incoming papers.',
          severity: 'high'
        },
        {
          area: 'Under & Behind Desk',
          problem: '5 cables hanging loose and tangling near your feet.',
          solution: 'Attach an under-desk cable management tray and bundle cords with velcro wraps.',
          severity: 'high'
        },
        {
          area: 'Right Hand Corner',
          problem: 'Multiple empty mugs and scattered stationery.',
          solution: 'Clear beverage containers daily and place pens into a single desktop organizer cup.',
          severity: 'medium'
        }
      ],
      declutterSteps: [
        {
          id: 's1',
          title: 'Clear Drinks & Trash',
          category: 'discard',
          estimatedMinutes: 3,
          priority: 'high',
          instructions: 'Remove all empty cups, water bottles, and scrap paper instantly.',
          targetArea: 'Right Desk Corner'
        },
        {
          id: 's2',
          title: 'Cable Triage & Bundle',
          category: 'organize',
          estimatedMinutes: 10,
          priority: 'high',
          instructions: 'Unplug non-essential cords, use velcro ties to group monitor and power cables.',
          targetArea: 'Behind Desk'
        },
        {
          id: 's3',
          title: 'Sort Paper Into 3 Piles',
          category: 'keep',
          estimatedMinutes: 8,
          priority: 'medium',
          instructions: 'Separate papers into: 1. Action Needed, 2. File Away, 3. Recycle.',
          targetArea: 'Desk Surface'
        },
        {
          id: 's4',
          title: 'Relocate Stray Gadgets',
          category: 'relocate',
          estimatedMinutes: 5,
          priority: 'low',
          instructions: 'Move extra headphones and USB drives into a dedicated drawer pouch.',
          targetArea: 'Left Desk Side'
        }
      ],
      storageRecommendations: [
        {
          name: 'Under-Desk Wire Mesh Cable Tray',
          category: 'Cable Mgmt',
          reason: 'Hides power strip and keeps cords suspended cleanly off the floor.',
          estimatedPriceRange: '$12 - $18',
          placement: 'Underneath back edge of desk'
        },
        {
          name: '3-Tier Mesh Paper & Document Tray',
          category: 'Containers',
          reason: 'Organizes loose papers vertically without taking up valuable desk real estate.',
          estimatedPriceRange: '$15 - $22',
          placement: 'Back right corner of desk'
        },
        {
          name: 'Minimalist Wooden Pen & Phone Stand',
          category: 'Desk Accessories',
          reason: 'Combines pen holder, phone charger dock, and sticky note holder in one footprint.',
          estimatedPriceRange: '$18 - $25',
          placement: 'Beside monitor'
        }
      ],
      spatialLayoutTips: [
        'Center your primary monitor directly in front of your chair, keeping a 12-inch clear zone on both sides for arm movement.',
        'Angle desktop lighting away from screens to minimize glare and eye strain.'
      ],
      quick15MinWin: 'Bundle all loose charger cables with velcro ties and toss away all paper trash!',
      suggestedChatPrompts: [
        'How can I organize my workspace so papers don’t pile up again?',
        'What is the best cable management strategy for a sitting-standing desk?',
        'Help me design a 5-minute end-of-day desk reset ritual.'
      ]
    }
  },
  {
    id: 'sample_closet',
    title: 'Overflowing Bedroom Closet',
    roomType: 'closet',
    goal: 'marie_kondo',
    description: 'Clothes spilling off hangers, shoes piled on floor, and stacked boxes threatening to fall.',
    imageUrl: createRoomSvg('#fdf2f8', 'Overflowing Wardrobe Closet', [
      'Piles of mixed shoes on closet floor',
      'Hangers mixed with mismatched jacket types',
      'Top shelf overflowing with unboxed sweaters',
      'Belts and scarves hanging over door frame'
    ]),
    presetAnalysis: {
      overallMessScore: 8.2,
      clutterLevelCategory: 'Heavy Overflow & Storage Misuse',
      roomSummary: 'Your closet contains great wardrobe pieces, but visual overwhelm occurs because vertical shelf space is underutilized and shoes lack dedicated cubbies.',
      identifiedIssues: [
        {
          area: 'Closet Floor',
          problem: 'Over 12 pairs of shoes randomly scattered on the floor.',
          solution: 'Install a 2-tier stackable shoe rack or hanging door organizer.',
          severity: 'high'
        },
        {
          area: 'Upper Shelf',
          problem: 'Bulky sweaters tumbling down due to lack of dividers.',
          solution: 'Use clear acrylic shelf dividers to keep folded stacks upright.',
          severity: 'medium'
        },
        {
          area: 'Hanging Bar',
          problem: 'Bulky plastic and wire hangers crowding clothes together.',
          solution: 'Switch to slim velvet non-slip hangers to double hanging capacity.',
          severity: 'medium'
        }
      ],
      declutterSteps: [
        {
          id: 'c1',
          title: 'The Spark Joy Clothes Sweep',
          category: 'donate_sell',
          estimatedMinutes: 15,
          priority: 'high',
          instructions: 'Pull out items unworn in 12 months. Place into a donation bag.',
          targetArea: 'Main Hanging Rod'
        },
        {
          id: 'c2',
          title: 'Pair & Rank Shoes',
          category: 'organize',
          estimatedMinutes: 10,
          priority: 'high',
          instructions: 'Group shoes by pair. Place daily shoes in front and seasonal shoes up top.',
          targetArea: 'Closet Floor'
        },
        {
          id: 'c3',
          title: 'Vertical Fold Sweaters',
          category: 'keep',
          estimatedMinutes: 12,
          priority: 'medium',
          instructions: 'Fold bulky knitwear file-style into fabric bins on upper shelf.',
          targetArea: 'Top Shelf'
        }
      ],
      storageRecommendations: [
        {
          name: 'Slim Non-Slip Velvet Hangers (Pack of 30)',
          category: 'Hanging Organizers',
          reason: 'Saves up to 50% closet rod width while preventing clothes from slipping off.',
          estimatedPriceRange: '$20 - $28',
          placement: 'Main closet hanging rod'
        },
        {
          name: 'Clear Acrylic Shelf Dividers (4-Pack)',
          category: 'Vertical Storage',
          reason: 'Prevents folded towels and sweaters from leaning or falling over.',
          estimatedPriceRange: '$16 - $24',
          placement: 'Top closet shelf'
        },
        {
          name: 'Over-The-Door 24-Pocket Shoe & Accessory Organizer',
          category: 'Containers',
          reason: 'Frees up entire closet floor by using empty door space for shoes or accessories.',
          estimatedPriceRange: '$14 - $20',
          placement: 'Inside closet door'
        }
      ],
      spatialLayoutTips: [
        'Organize hanging clothes by category (shirts, pants, dresses) then by color gradient from light to dark.',
        'Keep seasonal clothes in vacuum seal storage bags on the topmost shelf.'
      ],
      quick15MinWin: 'Pair all scattered shoes and line them up, then donate 5 items you haven’t worn this year!',
      suggestedChatPrompts: [
        'How do I fold sweaters using the Marie Kondo method?',
        'What should I do with clothes that are worn once but not dirty yet?',
        'How can I capsule my wardrobe to keep my closet spacious?'
      ]
    }
  },
  {
    id: 'sample_kitchen',
    title: 'Cluttered Kitchen Pantry',
    roomType: 'pantry',
    goal: 'family',
    description: 'Half-empty snack boxes, duplicate canned goods, and spice bottles hiding behind large boxes.',
    imageUrl: createRoomSvg('#f0fdf4', 'Kitchen Pantry Shelves', [
      'Multiple open snack bags losing freshness',
      'Duplicate cereal boxes cluttering front shelves',
      'Spices & sauces hidden behind large cans',
      'Baking supplies mixed with breakfast items'
    ]),
    presetAnalysis: {
      overallMessScore: 6.8,
      clutterLevelCategory: 'Moderate Zone Confusion',
      roomSummary: 'Your pantry has plenty of shelf space! Grouping food items by category (Snacks, Baking, Canned Goods, Breakfast) will cut meal-prep time in half.',
      identifiedIssues: [
        {
          area: 'Eye-Level Shelf',
          problem: 'Snack bags open and scattered, making items hard to find.',
          solution: 'Store open snacks in clear labeled pull-out bins.',
          severity: 'high'
        },
        {
          area: 'Lower Shelves',
          problem: 'Heavy cans blocked by cereal boxes.',
          solution: 'Use a 3-tier expandable step shelf for full visibility of cans and jars.',
          severity: 'medium'
        }
      ],
      declutterSteps: [
        {
          id: 'p1',
          title: 'Expired Food Check',
          category: 'discard',
          estimatedMinutes: 5,
          priority: 'high',
          instructions: 'Check expiration dates on spices and canned goods. Toss expired items.',
          targetArea: 'All Shelves'
        },
        {
          id: 'p2',
          title: 'Decant Snacks Into Bins',
          category: 'organize',
          estimatedMinutes: 10,
          priority: 'high',
          instructions: 'Combine duplicate open bags into airtight container bins.',
          targetArea: 'Center Shelf'
        }
      ],
      storageRecommendations: [
        {
          name: 'Clear BPA-Free Pantry Storage Bins with Handles',
          category: 'Containers',
          reason: 'Allows quick pull-out access to grouped snacks and dry goods.',
          estimatedPriceRange: '$22 - $32',
          placement: 'Middle eye-level shelves'
        },
        {
          name: '3-Tier Tiered Spice & Can Rack',
          category: 'Vertical Storage',
          reason: 'Elevates rear items so you never buy duplicate cans again.',
          estimatedPriceRange: '$12 - $18',
          placement: 'Pantry back shelf'
        }
      ],
      spatialLayoutTips: [
        'Place heavy items like rice sacks and oil gallons on bottom shelves.',
        'Put kid-friendly snacks on lower accessible shelves.'
      ],
      quick15MinWin: 'Throw away expired items and put all snack bags into one container bin!',
      suggestedChatPrompts: [
        'How should I label my pantry bins for easy family maintenance?',
        'What are the best airtight containers for flour and sugar?'
      ]
    }
  }
];
