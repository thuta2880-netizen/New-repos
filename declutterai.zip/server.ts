import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

// Increase payload limit for base64 room image uploads
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Lazy init Gemini Client
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is missing.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Room Analysis API
app.post("/api/analyze-room", async (req, res) => {
  try {
    const { imageBase64, mimeType, roomType, organizationGoal, timeAvailable, specialNotes } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: "Missing image payload." });
    }

    const ai = getGeminiClient();

    // Clean base64 string if data URL prefix exists
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
    const actualMimeType = mimeType || "image/jpeg";

    const prompt = `You are a world-class professional room organizer and decluttering expert.
Analyze this photo of a ${roomType || "room"}.
The user's decluttering goal is: "${organizationGoal || "General Declutter & Organize"}".
They have approximately ${timeAvailable || "30-60 minutes"} available for this task.
${specialNotes ? `Special user request / focus: "${specialNotes}"` : ""}

Examine the photo in detail. Identify cluttered zones, surfaces, floor items, storage problems, cable tangles, and unorganized items.

Provide a comprehensive, encouraging, and structured decluttering & organization plan in JSON format.
The JSON object MUST follow this schema strictly:
{
  "overallMessScore": <number between 1.0 and 10.0, where 1.0 is immaculate and 10.0 is severely cluttered>,
  "clutterLevelCategory": "<string: e.g. 'Light Surface Clutter' | 'Moderate Disorganization' | 'Heavy Surface & Floor Accumulation' | 'Severe Overflow'>",
  "roomSummary": "<string: 2-3 encouraging sentences analyzing the room's main clutter pattern and potential>",
  "identifiedIssues": [
    {
      "area": "<string: e.g. 'Desk Surface', 'Left Corner Floor', 'Bookshelf Center', 'Cable Area'>",
      "problem": "<string: brief description of what is cluttered/out of place>",
      "solution": "<string: specific action to resolve this problem>",
      "severity": "<string: 'high' | 'medium' | 'low'>"
    }
  ],
  "declutterSteps": [
    {
      "id": "<string: e.g. 'step_1'>",
      "title": "<string: clear, actionable step title>",
      "category": "<string: 'keep' | 'donate_sell' | 'discard' | 'relocate' | 'organize'>",
      "estimatedMinutes": <number: estimated time in mins, e.g. 5, 10, 15>,
      "priority": "<string: 'high' | 'medium' | 'low'>",
      "instructions": "<string: step-by-step guidance on how to complete this task>",
      "targetArea": "<string: specific area in the photo>"
    }
  ],
  "storageRecommendations": [
    {
      "name": "<string: product or storage item name, e.g. 'Clear Stackable Acrylic Bins', 'Under-Desk Cable Tray', 'Vertical Pegboard Kit'>",
      "category": "<string: e.g. 'Containers', 'Cable Mgmt', 'Vertical Storage', 'Drawer Dividers', 'Hanging Organizers'>",
      "reason": "<string: why this item solves a problem seen in the room photo>",
      "estimatedPriceRange": "<string: e.g. '$10 - $20'>",
      "placement": "<string: where in the room to place or install it>"
    }
  ],
  "spatialLayoutTips": [
    "<string: actionable tip regarding furniture layout, lighting, or floor space optimization>",
    "<string: tip 2>"
  ],
  "quick15MinWin": "<string: one quick 5-15 minute task that will give an immediate visual impact and boost motivation>",
  "suggestedChatPrompts": [
    "<string: e.g. 'How do I organize all those loose papers on the desk?'>",
    "<string: e.g. 'Where should I move the extra cords seen near the wall?'>",
    "<string: e.g. 'Help me set up a daily 5-minute reset routine for this space.'>"
  ]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [
        {
          inlineData: {
            mimeType: actualMimeType,
            data: cleanBase64,
          },
        },
        {
          text: prompt,
        },
      ],
      config: {
        systemInstruction:
          "You are DeclutterAI, an expert interior organizer. Always produce valid JSON matching the requested schema. Be specific to visual evidence in the photo.",
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text || "{}";
    const parsedData = JSON.parse(responseText);

    res.json({
      success: true,
      analysis: parsedData,
    });
  } catch (error: any) {
    console.error("Error in /api/analyze-room:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze room image.",
    });
  }
});

// AI Organization Coach Chat API
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, imageBase64, mimeType, roomContext } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    const ai = getGeminiClient();

    let systemInstruction = `You are DeclutterAI, an empathetic, non-judgmental, highly creative professional room organizer and decluttering coach.
Your mission is to help the user organize their space efficiently, reduce stress, build sustainable habits, and create a calm home or workspace.
Offer structured, actionable advice with bullet points or numbered lists when giving steps.
Keep tone warm, motivational, practical, and clear.`;

    if (roomContext) {
      systemInstruction += `\n\nCurrent Room Context:
- Room Type: ${roomContext.roomType || "Room"}
- Goal: ${roomContext.organizationGoal || "General organization"}
- Clutter Level: ${roomContext.clutterLevelCategory || "N/A"} (Score: ${roomContext.overallMessScore || "N/A"}/10)
- Room Summary: ${roomContext.roomSummary || "N/A"}`;
    }

    // Format chat history or latest message
    const formattedContents: any[] = [];

    // If image is attached with the chat request, add it to the first message or latest message
    if (imageBase64) {
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
      formattedContents.push({
        inlineData: {
          mimeType: mimeType || "image/jpeg",
          data: cleanBase64,
        },
      });
    }

    // Map conversation messages to GenAI format
    for (const msg of messages) {
      formattedContents.push({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content || msg.text || "" }],
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "I'm here to help you declutter and organize! How can I assist with your space today?";

    res.json({
      success: true,
      reply: replyText,
    });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to process chat message.",
    });
  }
});

// Compare Before & After Photos
app.post("/api/compare-after", async (req, res) => {
  try {
    const { beforeImageBase64, afterImageBase64, roomType } = req.body;

    if (!beforeImageBase64 || !afterImageBase64) {
      return res.status(400).json({ error: "Both before and after images are required." });
    }

    const ai = getGeminiClient();

    const cleanBefore = beforeImageBase64.replace(/^data:image\/\w+;base64,/, "");
    const cleanAfter = afterImageBase64.replace(/^data:image\/\w+;base64,/, "");

    const prompt = `You are a professional room organization judge and coach evaluating a Before and After room transformation for a ${roomType || "room"}.
Image 1 is BEFORE decluttering.
Image 2 is AFTER decluttering.

Evaluate the transformation and return a JSON object with this exact structure:
{
  "improvementPercentage": <number from 0 to 100 representing percentage improvement>,
  "congratulationsHeader": "<string: e.g. 'Sensational Transformation!', 'Huge Difference!', 'Great Progress!'>",
  "detailedFeedback": "<string: 2-3 sentences praising specific noticeable changes like clear surfaces, organized cords, better floor space>",
  "keyImprovementsNoted": [
    "<string: specific item or area fixed in After photo>",
    "<string: another positive change>"
  ],
  "proTipForMaintenance": "<string: 1 tip on how to keep this room looking this good long-term>"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [
        { inlineData: { mimeType: "image/jpeg", data: cleanBefore } },
        { inlineData: { mimeType: "image/jpeg", data: cleanAfter } },
        { text: prompt },
      ],
      config: {
        systemInstruction: "You evaluate room organization before and after photos. Always produce valid JSON.",
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text || "{}";
    const parsedData = JSON.parse(responseText);

    res.json({
      success: true,
      comparison: parsedData,
    });
  } catch (error: any) {
    console.error("Error in /api/compare-after:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to compare before and after photos.",
    });
  }
});

async function startServer() {
  // Vite middleware for dev mode vs static serve in prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DeclutterAI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
